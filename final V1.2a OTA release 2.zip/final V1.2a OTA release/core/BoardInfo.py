import json
import os
from wifi.connectionManager import *

def GetWifiInfo():
    cm = ConnectionManager()
    hotspot = cm._hotspot_connection
    hotspot_settings = hotspot.GetSettings()
    hotspot_secrets = hotspot.GetSecrets()
    
    ssid = hotspot_settings['802-11-wireless']['ssid']
    psk = hotspot_secrets['802-11-wireless-security']['psk']
    
    return ssid, psk

def GetWifiConnectionInfo():

    #TODO Figure out what the difference was supposed to be
    return GetWifiInfo()
    

    data = GetWifiInfo()
    ssid = "LEDERBORD288"
    password = "LED12382"
    for i in range(0, len(data)):
        if data[i][0] == 'ssid':
            ssid = data[i][1]
        elif data[i][0] == 'wpa_passphrase':
            password = data[i][1]
    return (ssid, password)

def generateInfo():
    json_dict = {
        "ssid": "blank_ssid",
        "password": "blank_password",
        "panelType": -1,
        "version": -1,
        "proto": -1
    }

    (json_dict['ssid'], json_dict['password']) = GetWifiConnectionInfo()

    for key in json_dict:
        print("{0}: {1}".format(key, json_dict[key]))

    with open('/info.json', 'w') as json_out:
        json.dump(json_dict, json_out, indent=1)

# def getEnvSettings():
#     json_dict = {
#         "ssid": "blank_ssid",
#         "password": "blank_password",
#         "panelType": 2,
#         "proto": -1
#     }

#     print(os.environ['LEDERBORD_PANEL_TYPE'])




