assets = {"res": "/res/",
          "fonts": "/res/fonts/",
          "images": "/res/images/"}