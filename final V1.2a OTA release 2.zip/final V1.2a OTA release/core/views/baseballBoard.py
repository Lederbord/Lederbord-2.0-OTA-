from rgbViews import *
import json
from rgbmatrix import graphics
import fcntl
from threading import Thread
from threading import Lock

BallsImage = Image.open('../res/images/balls.png').convert('RGB')
StrikesImage = Image.open('../res/images/strikes.png').convert('RGB')
OutsImage = Image.open('../res/images/outs.png').convert('RGB')

UpArrowImage = Image.open('../res/images/arrow_up.png').convert('RGB')
DownArrowImage = Image.open('../res/images/arrow_down.png').convert('RGB')

class BSOIndicator:

    def __init__(self, rootView, x, y, defBalls='0', defStrikes='0', defOuts='0'):
        self.__rootView__ = rootView
        self.__x__ = x
        self.__y__ = y
        self.rootDir = 'src/core/'
        self.resDir = 'res/'

        # Balls Text Image
        self.ballsImage = RGBImage(rootView, self.__x__, self.__y__+1, BallsImage)
        self.ballsLabel = RGBLabel(rootView, self.__x__+10, self.__y__, defBalls)
        # Strikes Text Image
        self.strikesImage = RGBImage(rootView, self.__x__+17, self.__y__+1, StrikesImage)
        self.strikesLabel = RGBLabel(rootView, self.__x__+27, self.__y__, defStrikes)
        # Outs Text Image
        self.outsImage = RGBImage(rootView, self.__x__+34, self.__y__+1, OutsImage)
        self.outsLabel = RGBLabel(rootView, self.__x__+44, self.__y__, defOuts)

    def setBalls(self, balls):
        self.ballsLabel.setText(balls)

    def setStrikes(self, strikes):
        self.strikesLabel.setText(strikes)

    def setOuts(self, outs):
        self.outsLabel.setText(outs)


class InningIndicator:

    def __init__(self, rootView, x, y, defInning="t1"):
        self.__rootView__ = rootView
        self.__x__ = x
        self.__y__ = y
        self.rootDir = 'src/core/'
        self.resDir = 'res/'
        # self.arrowUpImage = Image.open(self.resDir + 'images/arrow_up.png')
        # self.arrowUpImage = self.arrowUpImage.convert('RGB')
        # self.arrowDownImage = Image.open(self.resDir + 'images/arrow_down.png')
        # self.arrowDownImage = self.arrowDownImage.convert('RGB')
        # self.arrowLabel = RGBLabel(self.__rootView__, self.__x__, self.__y__, u"\u2193")
        #self.arrowLabel = RGBLabel(self.__rootView__, self.__x__, self.__y__, u"\u2038")
        if self.isTop(defInning):
            self.arrowLabel = RGBImage(self.__rootView__, self.__x__ - 1, self.__y__ + 1, UpArrowImage)
        else:
            self.arrowLabel = RGBImage(self.__rootView__, self.__x__ - 1, self.__y__ + 1, DownArrowImage)
        self.numLabel = RGBLabel(self.__rootView__, self.__x__+8, self.__y__, defInning[1:])
        #self.arrowLabel.setColor(graphics.Color(255, 255, 0))
        #self.numLabel.setColor(graphics.Color(255, 255, 0))

    def setInning(self, inning):
        self.numLabel.setText(inning[1:])
        if not self.isTop(inning):
            #self.arrowLabel.setText(u"\u2193")
            self.arrowLabel.setImage(DownArrowImage)
        else:
            #self.arrowLabel.setText(u"\u2191")
            self.arrowLabel.setImage(UpArrowImage)

    def isTop(self, inning):
        return inning[:1]=='t'


class BaseballBoard:

    def __init__(self, rootView, defaults=None):
        self.__rootView__ = rootView
        print("Baseball init Method called")

        print(defaults)

        if defaults==None:
            defaults = {
                "homeScore": "00",
                "awayScore": "00",
                "balls": "0",
                "strikes": "0",
                "outs": "0",
                "inning": "t1",
                "homeColor": {"R": 0, "G": 255, "B": 255},
                "awayColor": {"R": 0, "G": 255, "B": 255},
                "timeSeconds": "0"
            }


        # Views
        self.Home_score=defaults["homeScore"]
        self.Away_score=defaults["awayScore"]
        self.Inning=defaults["inning"]
        mins, secs = divmod(int(defaults["timeSeconds"]), 60)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        self.clock=timer
        self.Home_color=defaults["homeColor"]
        self.Away_color=defaults["awayColor"]
        self.Balls=defaults["balls"]
        self.Outs=defaults["outs"]
        self.Strikes=defaults["strikes"]


        self.awayLabel = RGBLabel(self.__rootView__, 0, 0, "GUEST")
        self.awayScore = RGBLabel(self.__rootView__, 0, 10, str(defaults["awayScore"]), TextStyle.IMAGE)
        self.homeScore = RGBLabel(self.__rootView__, 60, 10, str(defaults["homeScore"]), TextStyle.IMAGE)
        self.homeLabel = RGBLabel(self.__rootView__, 62, 0, "HOME")
        defAway = defaults["awayColor"]
        defHome = defaults["homeColor"]
        self.awayLabel.setColor(graphics.Color(defAway["R"], defAway["G"], defAway["B"]))
        self.homeLabel.setColor(graphics.Color(defHome["R"], defHome["G"], defHome["B"]))
        self.bsoIndicator = BSOIndicator(self.__rootView__, 0, 38, defBalls=defaults['balls'], defStrikes=defaults['strikes'], defOuts=defaults['outs'])
        self.inningIndicator = InningIndicator(self.__rootView__, 37, 0, defInning=defaults["inning"])
        #self.inningIndicator.setInning('b3')
        self.clockIndicator = Clock(self.__rootView__, 52, 38, defSeconds=defaults["timeSeconds"])
        self._lock = threading.Lock()

        #set remaining defaults through functions
        #self.setClock(defaults["time"])
        # self.setBalls(str(defaults["balls"]))
        # self.setStrikes(str(defaults["strikes"]))
        # self.setOuts(str(defaults["outs"]))
        #self.setInning(defaults["inning"])

    def setHomeScore(self, dataStr):
        print("Home score color called")
        #TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.homeScore.setText("0" + dataStr)
            self.Home_score=int(dataStr)
        else:
            self.homeScore.setText(dataStr)
            self.Home_score=int(dataStr)
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["homeScore"]=dataStr
    #         print(js["homeScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass

    def setHomeColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.homeLabel.setColor(graphics.Color(red, green, blue))
        self.Home_color = f'{{"R":{red},"G":{green},"B":{blue}}}'
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["homeColor"]=dataStr
    #         print(js["homeColor"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass

    def setAwayScore(self, dataStr):
        print("Away score called")
        # TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.awayScore.setText("0" + dataStr)
            self.Away_score=int(dataStr)
        else:
            self.awayScore.setText(dataStr)
            self.Away_score=int(dataStr)
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["awayScore"]=dataStr
    #         print(js["awayScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass

    def setAwayColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.awayLabel.setColor(graphics.Color(red, green, blue))
        self.Away_color = f'{{"R":{red},"G":{green},"B":{blue}}}'
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["awayColor"]=dataStr
    #         print(js["awayColor"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass


    def setClock(self, dataStr):
        self.clockIndicator.setTime(dataStr)
        self.clock=dataStr
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
                 self._lock.acquire()
                 data = f.read()
                 self._lock.release()
     #            print(data)
                 js = json.loads(data)
     #            print("File contents")
     #            print(js)
                 js["timeSeconds"]=dataStr
                 mm, ss = dataStr.split(':')
                 js["timeSeconds"]=int(mm) * 60 + int(ss)
    #             print(js["timeSeconds"])
                 with open('/usr/src/core/Score/current_score.txt','w') as f:
                     self._lock.acquire()
                     f.write(json.dumps(js))
                     self._lock.release()
        except Exception:
            pass

    def setBalls(self, dataStr):
        self.bsoIndicator.setBalls(dataStr)
        self.Balls=dataStr
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["balls"]=dataStr
    #         print(js["balls"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
            
    def setStrikes(self, dataStr):
        self.bsoIndicator.setStrikes(dataStr)
        self.Strikes=dataStr
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["strikes"]=dataStr
    #         print(js["strikes"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass

    def setOuts(self, dataStr):
        self.bsoIndicator.setOuts(dataStr)
        self.Outs=dataStr
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["outs"]=dataStr
    #         print(js["outs"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass

    def setInning(self, dataStr):
        self.inningIndicator.setInning(dataStr)
        self.Inning=dataStr
        try :
            with open('/usr/src/core/Score/current_score.txt') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["inning"]=dataStr
    #         print(js["inning"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
            
#    def setBrightness(self,dataStr):
#        print("Baseball -Brightness")
#        root=RGBBase()
#        root.setBrightness(dataStr)

    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))




    def startTimer(self,dataStr):
        print("Timer started")
        global timer_status
        global t
        timer_status=1
        if t==None:
           t=int(dataStr)
        while int(t):
            print("Loop") 
            if timer_status==1:
                mins, secs = divmod(int(t), 60)
                timer = '{:02d}:{:02d}'.format(mins, secs)
                print(timer, end="\r")
                self.clockIndicator.setTime(timer)
                self.clock=timer
                time.sleep(1)
                t -= 1


    def stopTimer(self,dataStr):
        print("Timer stop")
        global timer_status
        timer_status=0

    def  countdown(t,timer_status):
        print(t)
        while int(t):
            mins, secs = divmod(int(t), 60)
            timer = '{:02d}:{:02d}'.format(mins, secs)
            print(timer, end="\r")
            print("countdown task")
            self.setClock(self,timer)
            time.sleep(1)
            t -= 1



if __name__ == "__main__":
    print("Base ball Main called")
    root = RGBBase()
    baseball = BaseballBoard(root)
    while True:
        pass

