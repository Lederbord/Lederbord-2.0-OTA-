from PIL import Image
from rgbViews import *
from rgbmatrix import graphics
from BoardInfo import GetWifiInfo, GetWifiConnectionInfo


logo = Image.open('../res/images/lederbord_logo_small.png').convert('RGB')


class BootBoard:
    def __init__(self, rootView):
        self.rootDir = 'src/core/'
        self.resDir = 'res/'
        self.__rootView__ = rootView
        self.brightness = 255  # Default brightness value
        # self.logo = Image.open(self.resDir + 'images/lederbord_logo_small.png')
        # self.logo = self.logo.convert("RGB")
        # self.logo = self.resDir + 'images/lederbord_logo_small.png'
        # self.boardWidth = 96
        # wpercent = (self.boardWidth / float(self.logo.size[0]))
        # hsize = int((float(self.logo.size[1]) * float(wpercent)))
        # self.logo = self.logo.resize((self.boardWidth, hsize))
        self.bootImage = RGBImage(self.__rootView__,3, 5, logo)
        self.connectInfo = ConnectInfo(rootView, 0, 23)

        self.version_label = RGBLabel(self.__rootView__, 60, 33, 'v' + str(self.get_version()))
        print("ran")

    def get_version(self):
        version = "1.2a"
        print("Version: {}".format(version))

        #TODO remove: just so it runs
        return version

        path = '/home/pi/scoreboard-git/version/version.json'
        version = json.loads(open(path).read())
        print(version["version"])
        return version["version"]

    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))



#    def setBrightness(self, brightness_value):
#        try:
            # Ensure brightness is within a valid range, e.g., 0 to 255
#            brightness_value = max(0, min(600, int(float(brightness_value))))
#            self.brightness = brightness_value
#            print(f"Brightness set to: {self.brightness}")

#            print(brightness_value)
            # Implement logic to update brightness on the RGB matrix (if supported by hardware)
#        except ValueError:
#            print("Invalid brightness value")
 
             

class ConnectInfo:
    def __init__(self, rootView, x, y):
        self.__rootView__ = rootView
        self.__x__ = x
        self.__y__ = y
        self.ssid = ''
        self.password = ''

        # data = GetWifiInfo()
        # for i in range(0, len(data)):
        #     if data[i][0] == 'ssid':
        #         self.ssid = data[i][1]
        #     elif data[i][0] == 'wpa_passphrase':
        #         self.password = data[i][1]

        (self.ssid, self.password) = GetWifiConnectionInfo()


        self.ssid_label = RGBLabel(self.__rootView__, self.__x__, self.__y__, self.ssid)
        self.ssid_label.setColor(graphics.Color(0, 255, 0))
        self.password_label = RGBLabel(self.__rootView__, self.__x__, self.__y__ + 10, self.password)
        self.password_label.setColor(graphics.Color(0, 255, 255))

    # def getData(self):
    #     data = []
    #     dataFile = open("/etc/hostapd/hostapd.conf", "r")
    #     for line in dataFile:
    #         split = line.rstrip().split('=')
    #         data.append(split)
    #
    #     #print(data)
    #
    #     return data

if __name__ == "__main__":
    root = RGBBase()
    boot = BootBoard(root)
    while True:
        pass
