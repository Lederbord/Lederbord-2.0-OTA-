from PIL import Image
from core.rgbViews import *
from rgbmatrix import graphics
import sys


sys.path.append('src/shared/')
from shared.ConnectionStatus import ConnectionStatus


ConnectionStatusText = {
    ConnectionStatus.CONNECTING: ("Connecting to:", (255, 255, 255)),
    ConnectionStatus.CONNECTED: ("Connected to: ", (0, 255, 0)),
    ConnectionStatus.FAILED: ("Failed", (255, 0, 0)),
}

class ClientConnectBoard:
    def __init__(self, rootView, json=None):
        self.rootDir = 'src/core/'
        self.resDir = 'res/'
        self.__rootView__ = rootView
        

        if not self.are_params_valid(json):
            json = {
                "ssid": "def_ssid"
            }

        self.connected_to_label = RGBLabel(self.__rootView__, 3, 3, "Connected to: ")
        self.version_label = RGBLabel(self.__rootView__, 3, 28, json["ssid"])
        self.connection_status = self._set_connection_status(ConnectionStatus.CONNECTING)

    def _set_connection_status(self, new_status):
        self.set_status_text(new_status)
        if(new_status == ConnectionStatus.CONNECTED):
            #TODO what happens when we are connected
            pass
        elif(new_status == ConnectionStatus.CONNECTING):
            #TODO state transition to connecting
            pass
        elif(new_status == ConnectionStatus.FAILED):
            #TODO state transition when failed
            pass

    def set_status_text(self, new_status):
        text_color_pair = ConnectionStatusText[new_status]
        self.connected_to_label.setText(text_color_pair[0])
        self.connected_to_label.setColor(graphics.Color(*text_color_pair[1]))

    def set_connection_status(self, json=None):
        if not self.are_params_valid(json):
            return
        new_status = json["status"]
        for status in ConnectionStatus:
            if status.name == new_status:
                self._set_connection_status(status)
                return
        print(f"matching status not found: {new_status}")

    def are_params_valid(self, json):
        return json is not None and json != "" and json != []


    
    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))

       

if __name__ == "__main__":
    root = RGBBase()
    board = ClientConnectBoard(root)
    while True:
        pass
