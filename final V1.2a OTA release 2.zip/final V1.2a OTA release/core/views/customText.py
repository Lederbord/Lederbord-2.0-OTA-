from PIL import Image
from rgbViews import *
from rgbmatrix import graphics


logo = Image.open('../res/images/lederbord_logo_small.png').convert('RGB')


class customText:
    def __init__(self, rootView,defaults=None):
        self.rootDir = 'src/core/'
        self.resDir = 'res/'
        self.__rootView__ = rootView
        defLineonecolor = defaults["lineOneColor"]
        defLinetwocolor = defaults["lineTwoColor"]
        defLinethreecolor = defaults["lineThreeColor"]

        # self.logo = Image.open(self.resDir + 'images/lederbord_logo_small.png')
        # self.logo = self.logo.convert("RGB")
        # self.logo = self.resDir + 'images/lederbord_logo_small.png'
        # self.boardWidth = 96
        # wpercent = (self.boardWidth / float(self.logo.size[0]))
        # hsize = int((float(self.logo.size[1]) * float(wpercent)))
        # self.logo = self.logo.resize((self.boardWidth, hsize))
        self.TopLabel = RGBLabel(self.__rootView__, 3, 0,defaults["lineOne"])
        self.TopLabel.setColor(graphics.Color(defLineonecolor["R"], defLineonecolor["G"], defLineonecolor["B"]))
        self.MiddleLabel = RGBLabel(self.__rootView__, 3, 16, defaults["lineTwo"])
        self.MiddleLabel.setColor(graphics.Color(defLinetwocolor["R"], defLinetwocolor["G"], defLinetwocolor["B"]))
        self.BottomLabel = RGBLabel(self.__rootView__, 3, 33,defaults["lineThree"])
        self.BottomLabel.setColor(graphics.Color(defLinethreecolor["R"], defLinethreecolor["G"],defLinethreecolor["B"]))

#        self.version_label = RGBLabel(self.__rootView__, 65, 33, 'v' + str(self.get_version()))
        print("ran")

    def get_version(self):
        version = "0.3"
        print("Version: {}".format(version))

        #TODO remove: just so it runs
        return version

        path = '/home/pi/scoreboard-git/version/version.json'
        version = json.loads(open(path).read())
        print(version["version"])
        return version["version"]

    def setClock(self, dataStr):
        pass


    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))




if __name__ == "__main__":
    rootView = RGBBase()
    boot = customText(rootView)
    while True:
        pass
