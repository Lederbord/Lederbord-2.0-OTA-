from rgbViews import *
import json
import fcntl
from threading import Thread
from threading import Lock

class LacrosseBoard:

    def __init__(self, rootView, defaults=None):
        self.__rootView__ = rootView

        if defaults==None:
            #set default values here
            defaults = {
                "homeScore": "00",
                "awayScore": "00",
                "quarter": "1",
                "homeColor": {"R": 0, "G": 255, "B": 255},
                "awayColor": {"R": 0, "G": 255, "B": 255},
                "timeSeconds": "0"
            }

        self.Home_score=defaults["homeScore"]
        self.Away_score=defaults["awayScore"]
        self.quarter=defaults["quarter"]
        mins, secs = divmod(int(defaults["timeSeconds"]), 60)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        self.clock=timer
        self.Home_color=defaults["homeColor"]
        self.Away_color=defaults["awayColor"]

        # Views
        self.awayLabel = RGBLabel(self.__rootView__, 0, 0, "GUEST")
        self.awayScore = RGBLabel(self.__rootView__, 0, 10, defaults["awayScore"], TextStyle.IMAGE)
        self.homeLabel = RGBLabel(self.__rootView__, 62, 0, "HOME")
        self.homeScore = RGBLabel(self.__rootView__, 60, 10, defaults["homeScore"], TextStyle.IMAGE)
        defAway = defaults["awayColor"]
        defHome = defaults["homeColor"]
        self.awayLabel.setColor(graphics.Color(defAway["R"], defAway["G"], defAway["B"]))
        self.homeLabel.setColor(graphics.Color(defHome["R"], defHome["G"], defHome["B"]))
        self.clockIndicator = Clock(self.__rootView__, 26, 38, defSeconds=defaults['timeSeconds'])
        self.periodIndicator = PeriodIndicator(self.__rootView__, 43, 0, 'Q', defPeriod=defaults['quarter'])
        self._lock = threading.Lock()

    def setHomeScore(self, dataStr):
        # TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.homeScore.setText("0" + dataStr)
            self.Home_score=int(dataStr)
        else:
            self.homeScore.setText(dataStr)
            self.Home_score=int(dataStr)
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["homeScore"]=dataStr
#             print(js["homeScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
    def setHomeColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.homeLabel.setColor(graphics.Color(red, green, blue))
        self.Home_color = f'{{"R":{red},"G":{green},"B":{blue}}}'
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["homeColor"]=dataStr
#             print(js["homeColor"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
            
    def setAwayScore(self, dataStr):
        # TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.awayScore.setText("0" + dataStr)
            self.Away_score=int(dataStr)
        else:
            self.awayScore.setText(dataStr)
            self.Away_score=int(dataStr)
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["awayScore"]=dataStr
#             print(js["awayScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass          

    def setAwayColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.awayLabel.setColor(graphics.Color(red, green, blue))
        self.Away_color = f'{{"R":{red},"G":{green},"B":{blue}}}'
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["awayColor"]=dataStr
#             print(js["awayColor"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass 
    def setClock(self, dataStr):
        self.clockIndicator.setTime(dataStr)
        self.clock=dataStr
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
                 self._lock.acquire()
                 data = f.read()
                 self._lock.release()
                 js = json.loads(data)
#                 print("File contents")
#                 print(js)
                 js["timeSeconds"]=dataStr
                 mm, ss = dataStr.split(':')
                 js["timeSeconds"]=int(mm) * 60 + int(ss)
#                 print(js["timeSeconds"])
                 with open('/usr/src/core/Score/current_score.txt','w') as f:
                     self._lock.acquire()
                     f.write(json.dumps(js))
                     self._lock.release()
        except Exception:
            pass 
    def setQuarter(self, dataStr):
        self.periodIndicator.setPeriod(dataStr)
        self.quarter=dataStr
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["quarter"]=dataStr
#             print(js["quarter"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
                 self._lock.acquire()
                 f.write(json.dumps(js))
                 self._lock.release()
        except Exception:
            pass 

    def startTimer(self,dataStr):
        print("Waiting for timer start Event")
#        timer_event.wait()
        print("Timer started")
#    t =2400
#        timer_event.isSet()

        global timer_status
        global t
        timer_status=1
        if t==None:
           t=int(dataStr)
#        self.countdown(self.t,timer_status)
        while int(t):
            print("Loop") 
            if timer_status==1:
                mins, secs = divmod(int(t), 60)
                timer = '{:02d}:{:02d}'.format(mins, secs)
                print(timer, end="\r")
                self.clockIndicator.setTime(timer)
                self.clock=timer
                time.sleep(1)
                t -= 1
    
    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))



    def stopTimer(self,dataStr):
        print("Timer stop")
        global timer_status
        timer_status=0
#        self.countdown(self.t,timer_status)
#        timer_event.clear()


    def  countdown(t,timer_status):
#        timer_event.wait()
        print(t)
        while int(t):
            mins, secs = divmod(int(t), 60)
            timer = '{:02d}:{:02d}'.format(mins, secs)
            print(timer, end="\r")
            print("countdown task")
            self.setClock(self,timer)
            time.sleep(1)
            t -= 1








if __name__ == "__main__":
    rootView = RGBBase()
    board = LacrosseBoard(rootView)
    while True:
        pass
