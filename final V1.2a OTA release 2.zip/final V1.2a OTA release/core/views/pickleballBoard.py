from rgbViews import *
import json
from rgbmatrix import graphics
from threading import Thread
from threading import Lock

LeftArrowImage = Image.open('../res/images/arrow_left.png').convert('RGB')
RightArrowImage = Image.open('../res/images/arrow_right.png').convert('RGB')





class ServeIndicator:

    def __init__(self, rootView, x, y, defInning="h1"):
        self.__rootView__ = rootView
        self.__x__ = x
        self.__y__ = y
        self.rootDir = 'src/core/'
        self.resDir = 'res/'
        # self.arrowUpImage = Image.open(self.resDir + 'images/arrow_up.png')
        # self.arrowUpImage = self.arrowUpImage.convert('RGB')
        # self.arrowDownImage = Image.open(self.resDir + 'images/arrow_down.png')
        # self.arrowDownImage = self.arrowDownImage.convert('RGB')
        # self.arrowLabel = RGBLabel(self.__rootView__, self.__x__, self.__y__, u"\u2193")
        #self.arrowLabel = RGBLabel(self.__rootView__, self.__x__, self.__y__, u"\u2038")
        if self.isTop(defInning):
            self.arrowLabel = RGBImage(self.__rootView__, self.__x__ - 1, self.__y__ + 1, LeftArrowImage)
        else:
            self.arrowLabel = RGBImage(self.__rootView__, self.__x__ - 1, self.__y__ + 1, RightArrowImage)
        self.numLabel = RGBLabel(self.__rootView__, self.__x__+8, self.__y__, defInning[1:])
        #self.arrowLabel.setColor(graphics.Color(255, 255, 0))
        #self.numLabel.setColor(graphics.Color(255, 255, 0))

    def setInning(self, inning):
        self.numLabel.setText(inning[1:])
        if not self.isTop(inning):
            #self.arrowLabel.setText(u"\u2193")
            self.arrowLabel.setImage(RightArrowImage)
        else:
            #self.arrowLabel.setText(u"\u2191")
            self.arrowLabel.setImage(LeftArrowImage)

    def isTop(self, inning):
        return inning[:1]=='h'













class PickelBallBoard:

    def __init__(self, rootView, defaults=None):
        self.__rootView__ = rootView

        if defaults==None:
            #set default values here
            defaults = {
                "homeScore": "00",
                "awayScore": "00",
                "homeColor": {"R": 0, "G": 255, "B": 255},
                "awayColor": {"R": 0, "G": 255, "B": 255},
                "homeServe": "h0",
                "awayServe": "a0",
                "currentServe":"00",
                "awaywinScore": "00",
                "homewinScore": "00",
            }

        # Views
        self.Home_score=defaults["homeScore"]
        self.Away_score=defaults["awayScore"]
#        self.half=None
#        self.clock=None
        self.Home_color=defaults["homeColor"]
        self.Away_color=defaults["awayColor"]
        self.Awaywin_score=defaults["awaywinScore"]
        self.CurrentServe=defaults["currentServe"]
        self.HomeServe=defaults["homeServe"]
        self.AwayServe=defaults["awayServe"]
        self.Homewin_score=defaults["homewinScore"]


        self.awayLabel = RGBLabel(self.__rootView__, 0, 0, "GUEST")
        self.awayScore = RGBLabel(self.__rootView__, 0, 12, defaults["awayScore"], TextStyle.IMAGE)
        self.homeLabel = RGBLabel(self.__rootView__, 62, 0, "HOME")
        self.homeScore = RGBLabel(self.__rootView__, 60, 12, defaults["homeScore"], TextStyle.IMAGE)
        defAway = defaults["awayColor"]
        defHome = defaults["homeColor"]
        self.awayLabel.setColor(graphics.Color(defAway["R"], defAway["G"], defAway["B"]))
        self.homeLabel.setColor(graphics.Color(defHome["R"], defHome["G"], defHome["B"]))
        self.serveIndicator = ServeIndicator(self.__rootView__, 37, 0, defInning=defaults["currentServe"])
        self.awaywinScore = RGBLabel(self.__rootView__, 17, 37, defaults["awaywinScore"])
        self.homewinScore = RGBLabel(self.__rootView__, 74, 37, defaults["homewinScore"])
        self._lock = threading.Lock()
#        defAway = defaults["awaywinColor"]
#        defHome = defaults["homewinColor"]
#        self.awaywinScore.setColor(graphics.Color(defAway["R"], defAway["G"], defAway["B"]))
#        self.homewinScore.setColor(graphics.Color(defHome["R"], defHome["G"], defHome["B"]))


    def setAwayScore(self, dataStr):
        # TODO make app send correct data instead of fixing here
        print("Setting Away Score")
        if len(dataStr) == 1:
            self.awayScore.setText("0" + dataStr)
            self.Away_score=int(dataStr)
        else:
            self.awayScore.setText(dataStr)
            self.Away_score=int(dataStr)
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["awayScore"]=dataStr
#             print(js["awayScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
    def setAwayColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.awayLabel.setColor(graphics.Color(red, green, blue))
        self.Away_color = f'{{"R":{red},"G":{green},"B":{blue}}}'
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["awayColor"]=dataStr
#             print(js["awayColor"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
    def setHomeScore(self, dataStr):
        print("Setting Home Score")
        # TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.homeScore.setText("0" + dataStr)
            self.Home_score=int(dataStr)
        else:
            self.homeScore.setText(dataStr)
            self.Home_score=int(dataStr)
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["homeScore"]=dataStr
#             print(js["homeScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()           
        except Exception:
            pass
    def setHomeColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.homeLabel.setColor(graphics.Color(red, green, blue))
        self.Home_color = f'{{"R":{red},"G":{green},"B":{blue}}}'
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release() 
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["homeColor"]=dataStr
#             print(js["homeColor"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release() 
        except Exception:
            pass
    def setserve(self, dataStr):
        print("Setting Serve")
        print(dataStr)
        self.serveIndicator.setInning(dataStr)
        print(dataStr[0])
        if dataStr[0]=='a':
           self.AwayServe=dataStr
           self.CurrentServe=dataStr
           try :
               with open('/usr/src/core/Score/current_score.txt','r') as f:
                  self._lock.acquire()
                  data = f.read()
                  self._lock.release() 
                  js = json.loads(data)
#                  print("File contents")
#                  print(js)
                  js["awayServe"]=dataStr
                  js["currentServe"]=dataStr
#                  print(js["awayServe"])
                  with open('/usr/src/core/Score/current_score.txt','w') as f:
                    self._lock.acquire()
                    f.write(json.dumps(js))
                    self._lock.release() 
#                   print(js)
           except Exception:
               pass                
        else:
           self.HomeServe=dataStr
           self.CurrentServe=dataStr
           try :
               with open('/usr/src/core/Score/current_score.txt','r') as f:
                  self._lock.acquire()
                  data = f.read()
                  self._lock.release() 
                  js = json.loads(data)
#                  print("File contents")
#                  print(js)
                  js["homeServe"]=dataStr
                  js["currentServe"]=dataStr
#                  print(js["homeServe"])
                  with open('/usr/src/core/Score/current_score.txt','w') as f:
                    self._lock.acquire()
                    f.write(json.dumps(js))
                    self._lock.release() 
#                    print(js)
           except Exception:
               pass  
    def setAwaywinscore(self, dataStr):
        print("Setting Away Win score")
        print(dataStr)
        if len(dataStr) == 1:
            self.awaywinScore.setText("0" + dataStr)
            self.Awaywin_score=int(dataStr)
        else:
            self.awaywinScore.setText(dataStr)
            self.Awaywin_score=int(dataStr)
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["awaywinScore"]=dataStr
#             print(js["awaywinScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
               pass  

    def setHomewinscore(self, dataStr):
        print("Setting Home win score")
        print(dataStr)
        if len(dataStr) == 1:
            self.homewinScore.setText("0" + dataStr)
            self.Homewin_score=int(dataStr)
        else:
            self.homewinScore.setText(dataStr)
            self.Homewin_score=int(dataStr)
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["homewinScore"]=dataStr
#             print(js["homewinScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
               pass



    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))




    def setClock(self, dataStr):
        pass


if __name__ == "__main__":
    rootView = RGBBase()
    board = PickelBallBoard(rootView)
