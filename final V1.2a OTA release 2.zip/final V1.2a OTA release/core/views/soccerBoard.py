from core.rgbViews import *
import json
import time
from threading import Timer
from threading import Thread
from threading import Lock
timer_status=None
t=None
import fcntl

class SoccerBoard:


    def __init__(self, rootView, defaults=None):
        self.__rootView__ = rootView

        if defaults==None:
            #set default values here
            defaults = {
                "homeScore": "00",
                "awayScore": "00",
                "half": "1",
                "homeColor": {"R": 0, "G": 255, "B": 255},
                "awayColor": {"R": 0, "G": 255, "B": 255},
                "timeSeconds": "0"
            }

        # Views
        self.Home_score=defaults["homeScore"]
        self.Away_score=defaults["awayScore"]
        self.half=defaults["half"]
        mins, secs = divmod(int(defaults["timeSeconds"]), 60)
        timer = '{:02d}:{:02d}'.format(mins, secs)
        self.clock=timer
        self.Home_color=defaults["homeColor"]
        self.Away_color=defaults["awayColor"]
#        self.t=None
        self.awayLabel = RGBLabel(self.__rootView__, 0, 0, "GUEST")
        self.awayScore = RGBLabel(self.__rootView__, 0, 10, defaults["awayScore"], TextStyle.IMAGE)
        self.homeLabel = RGBLabel(self.__rootView__, 62, 0, "HOME")
        self.homeScore = RGBLabel(self.__rootView__, 60, 10, defaults["homeScore"], TextStyle.IMAGE)
        defAway = defaults["awayColor"]
        defHome = defaults["homeColor"]
        self.awayLabel.setColor(graphics.Color(defAway["R"], defAway["G"], defAway["B"]))
        self.homeLabel.setColor(graphics.Color(defHome["R"], defHome["G"], defHome["B"]))
        self.clockIndicator = Clock(self.__rootView__, 26, 38, defSeconds=defaults['timeSeconds'])
        # self.halfIndicator = RGBLabel(self.__rootView__, 43, 0, 'H1')
        self.halfIndicator = PeriodIndicator(self.__rootView__, 43, 0, "H", defPeriod=defaults['half'])
        #self.halfIndicator.setColor(graphics.Color(255, 255, 0))
        self._lock = threading.Lock()

    def setHomeScore(self, dataStr):
#        global Home_score
        print(f"============================setHomesetHomeScore={dataStr}============")
        # TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.homeScore.setText("0" + dataStr)
            self.Home_score=int(dataStr)
        else:
            self.homeScore.setText(dataStr)
            self.Home_score=int(dataStr)
        try :
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             print("Home Read Lock aquired") 
             data = f.read()       
             self._lock.release()
             print("Home Read Lock released") 
             print(data)
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["homeScore"]=dataStr
    #         print(js["homeScore"])    
            with open('/usr/src/core/Score/current_score.txt','w') as f:
                 self._lock.acquire()
                 print("Home write Lock acquired") 
                 f.write(json.dumps(js))
                 self._lock.release()
                 print("Home write Lock released") 
        except Exception:
            print("Exception-File opening")
            pass
#           for key, value in js.items():  
#              f.write('%s:%s\n' % (key, value))
#        os.system(f"sed -i 's/homeScore:[0-9]*/homeScore:{dataStr}/g' /usr/src/core/Score/current_score_soccer.txt")

    def setHomeColor(self, dataStr):
        print("============================setHomeColor=============================")
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.homeLabel.setColor(graphics.Color(red, green, blue))
#        self.Home_color="{\"R\":{red},\"G\":{green},\"B\":{blue}}"
        self.Home_color = f'{{"R":{red},"G":{green},"B":{blue}}}'
        try :        
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()   
             data = f.read()
             self._lock.release()
             print(data)
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["homeColor"]=dataStr
    #         print(js["homeColor"])
            with open('/usr/src/core/Score/current_score.txt','w') as f:
                 self._lock.acquire() 
                 f.write(json.dumps(js))
                 self._lock.release()
        except Exception:
            pass     


    def setAwayScore(self, dataStr):
        # TODO make app send correct data instead of fixing here
        print("============================setAwayScore=============================")
        if len(dataStr) == 1:
            self.awayScore.setText("0" + dataStr)
            self.Away_score=int(dataStr)
        else:
            self.awayScore.setText(dataStr)
            self.Away_score=int(dataStr)
        try :         
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             print("Read Lock aquired")         
             data = f.read()
             self._lock.release()
             print("Read Lock released")          
             print(data)
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["awayScore"]=dataStr
    #         print(js["awayScore"])
            with open('/usr/src/core/Score/current_score.txt','w') as f:
                 self._lock.acquire()
                 print("Write Lock aquired")   
                 f.write(json.dumps(js))
                 self._lock.release()
                 print("Write Lock released")
        except Exception:
            print("Exception-File opening")
            pass                     
           

#        os.system(f"sed -i 's/awayScore:[0-9]*/awayScore:{dataStr}/g' /usr/src/core/Score/current_score_soccer.txt")

    def setAwayColor(self, dataStr):
        print("============================setAwayColor=============================")
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.awayLabel.setColor(graphics.Color(red, green, blue))
#        self.Away_color="{\"R\":{red},\"G\":{green},\"B\":{blue}}"
        self.Away_color = f'{{"R":{red},"G":{green},"B":{blue}}}' 
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             print(data)
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["awayColor"]=dataStr
    #         print(js["awayColor"])
            with open('/usr/src/core/Score/current_score.txt','w') as f:
                 self._lock.acquire()
                 f.write(json.dumps(js))
                 self._lock.release()
        except Exception:
            pass          


    def setClock(self, dataStr):
        print("Clock data")
        self.clockIndicator.setTime(dataStr)
        self.clock=dataStr
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
                 self._lock.acquire()
                 print("Clock read Lock aquired")   
                 data = f.read()
                 self._lock.release()
                 print("Clock read Lock released")   
                 print(data)
                 js = json.loads(data)
    #            print("File contents")
    #            print(js)
                 js["timeSeconds"]=dataStr
                 mm, ss = dataStr.split(':')
                 js["timeSeconds"]=int(mm) * 60 + int(ss)
    #             print(js["timeSeconds"])
            with open('/usr/src/core/Score/current_score.txt','w') as f:
                 self._lock.acquire()
                 print("Clock write Lock aquired")
                 f.write(json.dumps(js))
                 self._lock.release()
                 print("Clock write Lock released")
        except Exception:
            pass                 



    def setHalf(self, dataStr):
        self.halfIndicator.setPeriod(dataStr)
        self.half=dataStr
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             print(data)
             js = json.loads(data)
    #         print("File contents")
    #         print(js)
             js["half"]=dataStr
    #         print(js["half"])
            with open('/usr/src/core/Score/current_score.txt','w') as f:
                 self._lock.acquire()
                 f.write(json.dumps(js))
                 self._lock.release()
        except Exception:
            pass 
           



    def startTimer(self,dataStr):
        print("Waiting for timer start Event")
#        timer_event.wait()
        print("Timer started")
#    t =2400
#        timer_event.isSet()

        global timer_status
        global t
        timer_status=1
        if t==None:
           t=int(dataStr)
#        self.countdown(self.t,timer_status)
        while int(t):
            print("Loop") 
            if timer_status==1:
                try :
                    with open('/usr/src/core/Score/current_score.txt','r') as f:
                      self._lock.acquire()
                      data = f.read()
                      self._lock.release()
                      print(data)
                      js = json.loads(data)
    #                  print("File contents")
    #                  print(js)
                      js["timeSeconds"]=t
    #                  print(js["timeSeconds"])
                    with open('/usr/src/core/Score/current_score.txt','w') as f:
                        self._lock.acquire()
                        f.write(json.dumps(js))
                        self._lock.release()
                except Exception:
                    pass                    
                mins, secs = divmod(int(t), 60)
                timer = '{:02d}:{:02d}'.format(mins, secs)
                print(timer, end="\r")
                self.clockIndicator.setTime(timer)
                self.clock=timer
                time.sleep(1)
                t -= 1


    def stopTimer(self,dataStr):
        print("Timer stop")
        global timer_status
        timer_status=0
#        self.countdown(self.t,timer_status)
#        timer_event.clear()

    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))

    def  countdown(t,timer_status):
#        timer_event.wait()
        print(t)
        while int(t):
            try :
                with open('/usr/src/core/Score/current_score.txt','r') as f:
                      self._lock.acquire()
                      data = f.read()
                      self._lock.release()
                      print(data)
                      js = json.loads(data)
    #                  print("File contents")
    #                  print(js)
                      js["timeSeconds"]=t
    #                  print(js["timeSeconds"])
                with open('/usr/src/core/Score/current_score.txt','w') as f:
                      self._lock.acquire()
                      f.write(json.dumps(js))
                      self._lock.release()
            except Exception:
                 pass 
            mins, secs = divmod(int(t), 60)
            timer = '{:02d}:{:02d}'.format(mins, secs)
            print(timer, end="\r")
            print("countdown task")
            self.setClock(self,timer)
            time.sleep(1)
            t -= 1



if __name__ == "__main__":
    rootView = RGBBase()
    board = SoccerBoard(rootView)
    while True:
        pass
