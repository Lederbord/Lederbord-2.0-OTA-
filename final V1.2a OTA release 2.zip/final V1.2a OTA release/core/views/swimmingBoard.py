from rgbViews import *
import json
from rgbmatrix import graphics
from threading import Thread
from threading import Lock


class SwimmingBoard:

    def __init__(self, rootView, defaults=None):
        self.__rootView__ = rootView

        if defaults==None:
            #set default values here
            defaults = {
                "homeScore": "00",
                "awayScore": "00",
                "eventColor": {"R": 0, "G": 255, "B": 255},
                "heatColor": {"R": 0, "G": 255, "B": 255},
            }

        # Views
        self.Heat=defaults["awayScore"]
        self.Event=defaults["homeScore"]


        self.eventLabel = RGBLabel(self.__rootView__, 0, 0, "EVENT")
        self.eventScore = RGBLabel(self.__rootView__, 0, 12, defaults["homeScore"], TextStyle.IMAGE)
        self.heatLabel = RGBLabel(self.__rootView__, 69, 0, "HEAT")
        self.heatScore = RGBLabel(self.__rootView__, 60, 12, defaults["awayScore"], TextStyle.IMAGE)
        defEvent = defaults["eventColor"]
        defHeat = defaults["heatColor"]
        self.eventLabel.setColor(graphics.Color(defEvent["R"], defEvent["G"], defEvent["B"]))
        self.heatLabel.setColor(graphics.Color(defHeat["R"], defHeat["G"], defHeat["B"]))
        self._lock = threading.Lock()

    def setHomeScore(self, dataStr):
        # TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.eventScore.setText("0" + dataStr)
            self.Event=int(dataStr)
        else:
            self.eventScore.setText(dataStr)
            self.Event=int(dataStr)
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["homeScore"]=dataStr
#             print(js["homeScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
    def setAwayColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.eventLabel.setColor(graphics.Color(red, green, blue))

    def setAwayScore(self, dataStr):
        # TODO make app send correct data instead of fixing here
        if len(dataStr) == 1:
            self.heatScore.setText("0" + dataStr)
            self.Heat=int(dataStr)
        else:
            self.heatScore.setText(dataStr)
            self.Heat=int(dataStr)
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["awayScore"]=dataStr
#             print(js["awayScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass
    def setHeatColor(self, dataStr):
        colorObject = json.loads(dataStr)
        red = int(colorObject["R"])
        green = int(colorObject["G"])
        blue = int(colorObject["B"])
        self.heatLabel.setColor(graphics.Color(red, green, blue))

    def setEvent(self, dataStr):
        if len(dataStr) == 1:
            self.eventScore.setText("0" + dataStr)
            self.Event=int(dataStr) 
        else:
            self.eventScore.setText(dataStr)
            self.Event=int(dataStr)
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["homeScore"]=dataStr
#             print(js["homeScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass

    def setHeat(self, dataStr):
        if len(dataStr) == 1:
            self.heatScore.setText("0" + dataStr)
            self.Heat=int(dataStr)
        else:
            self.heatScore.setText(dataStr)
            self.Heat=int(dataStr)
        try : 
            with open('/usr/src/core/Score/current_score.txt','r') as f:
             self._lock.acquire()
             data = f.read()
             self._lock.release()
             js = json.loads(data)
#             print("File contents")
#             print(js)
             js["awayScore"]=dataStr
#             print(js["awayScore"])
             with open('/usr/src/core/Score/current_score.txt','w') as f:
               self._lock.acquire()
               f.write(json.dumps(js))
               self._lock.release()
        except Exception:
            pass


    
    def setBrightness(self,dataStr):
        print("Brightness")
        self.__rootView__.setBrightness(int(float(dataStr)))
        print(int(float(dataStr)))


            

    def setClock(self, dataStr):
        pass

if __name__ == "__main__":
    rootView = RGBBase()
    board = SwimmingBoard(rootView)
    while True:
        pass

